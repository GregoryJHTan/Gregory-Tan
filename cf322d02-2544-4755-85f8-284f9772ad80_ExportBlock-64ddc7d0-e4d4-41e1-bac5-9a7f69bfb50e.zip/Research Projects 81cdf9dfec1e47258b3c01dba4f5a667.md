# Research Projects

A space for ongoing and completed research projects.

## Contents

- Current projects
- Completed projects
- Research notes