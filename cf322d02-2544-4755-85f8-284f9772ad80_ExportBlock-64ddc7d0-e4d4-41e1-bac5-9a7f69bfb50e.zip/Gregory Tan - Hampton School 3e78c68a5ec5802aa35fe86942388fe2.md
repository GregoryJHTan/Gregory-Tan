# Gregory Tan - Hampton School

Welcome to my Notion page.

I am Gregory Tan, a Year 10 student at Hampton school, prospecting for top places in the Russell Group (Such as LSE&P, Oxbridge) doing a combined IR and Journalism degree. I am based in the United Kingdom for my studies, but mainly have family and connections in SEA.

This page is to communicate my academic and professional goals, achievements along with my writing and research projects.

## Explore

<aside>

Journalism

My articles, interviews, comments and plans for future work.

[Writing](Writing%20681d3e6030a74f9cbfb9e2d01c92b349.md)

</aside>

<aside>

Briefings

Issue briefs, focused on SEA.

[Briefings](Briefings%20eaed160ce94a4109bee265b2a2db33d0.md)

</aside>

<aside>

Research Projects

My ongoing  and completed Research essays

[Research Projects](Research%20Projects%2081cdf9dfec1e47258b3c01dba4f5a667.md)

</aside>

<aside>

About Me

My Biography

[About Me](About%20Me%20a83587500c604b78b56d34074b3d81e5.md)

</aside>

[Briefings](Briefings%20eaed160ce94a4109bee265b2a2db33d0.md)

[Research Projects](Research%20Projects%2081cdf9dfec1e47258b3c01dba4f5a667.md)

[About Me](About%20Me%20a83587500c604b78b56d34074b3d81e5.md)

[Writing](Writing%20681d3e6030a74f9cbfb9e2d01c92b349.md)